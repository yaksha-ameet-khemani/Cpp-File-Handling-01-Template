#include <iostream>
#include <string>
#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>
#include "tests/test_cases.cpp"
#include <gtest/gtest.h>
#include <fstream>
#include <sstream>
#include "tests/utils/testUtils.cpp"

using namespace curlpp::options;
using namespace std;

int main(int argc, char **argv) {
    // readCustomFileData("././commands.txt");
    TestUtils t;
    // cout<<t.readCustomFileData("commands.txt");
    t.yakshaAssert("testName", false, "testType");
    // testing::InitGoogleTest(&argc, argv);
    // return RUN_ALL_TESTS();
}
