#include <iostream>
#include <string>
#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>
#include <gtest/gtest.h>
#include <fstream>
#include <sstream>

using namespace curlpp::options;
using namespace std;

int isFilePresent(const char* fileName) {
    // write your logic here
    return 0;
}

int createFileAndWriteData(const char* fileName, string data) {
    // write your logic here
    return 0;
}

int openFileAndAppendData(const char* fileName, string data) {
    // write your logic here
    return 0;
}

string readData(const char* fileName) {
    // write your logic here
    return "";
}

int searchText(const char* fileName, string search) {
    // write your logic here
    return 0;
}
