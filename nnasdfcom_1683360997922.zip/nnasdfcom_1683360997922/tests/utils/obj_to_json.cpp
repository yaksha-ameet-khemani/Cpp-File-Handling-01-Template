#include <nlohmann/json.hpp>
#include "./testCaseResult.cpp"
#include "./testResults.cpp"
// #include "./testUtils.cpp"

// for convenience
using json = nlohmann::json;

namespace ns {
    // a simple struct to model a person
    struct person {
        std::string name;
        std::string address;
        int age;
    };
}

json getJson() {
    ns::person p = {"Ned Flanders", "744 Evergreen Terrace", 60};

    // convert to JSON: copy each value into the JSON object
    json j;
    j["name"] = p.name;
    j["address"] = p.address;
    j["age"] = p.age;

    return j;
}